import streamlit as st
import httpx

from langchain_openai import ChatOpenAI
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import FakeEmbeddings

# -----------------------------------
# PAGE CONFIG
# -----------------------------------

st.set_page_config(
    page_title="Manufacturing Quality Assistant",
    page_icon="🏭",
    layout="wide"
)

st.title("🏭 Manufacturing Quality Incident Insight Assistant")

st.markdown("""
AI assistant for analyzing:
- defect spikes
- process deviations
- quality incidents
- manufacturing failures
""")

# -----------------------------------
# LLM SETUP
# -----------------------------------

client = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key="YOUR_API_KEY",
    http_client=client,
    streaming=True
)

# -----------------------------------
# LOAD VECTOR DATABASE
# -----------------------------------

embeddings = FakeEmbeddings(size=384)

vectorstore = FAISS.load_local(
    "faiss_index",
    embeddings,
    allow_dangerous_deserialization=True
)

retriever = vectorstore.as_retriever(
    search_kwargs={"k": 3}
)

# -----------------------------------
# USER INPUT
# -----------------------------------

incident_query = st.text_area(
    "Enter Manufacturing Incident Details",
    height=180,
    placeholder="""
Example:
Surface scratches increased in gearbox production.
Machine vibration unusually high.
Defect rate increased by 20%.
"""
)

# -----------------------------------
# ANALYZE BUTTON
# -----------------------------------

if st.button("Analyze Incident"):

    if incident_query.strip() == "":
        st.warning("Please enter incident details.")
        st.stop()

    # -----------------------------------
    # RETRIEVE SIMILAR INCIDENTS
    # -----------------------------------

    docs = retriever.invoke(incident_query)

    context = "\n\n".join(
        [doc.page_content for doc in docs]
    )

    # -----------------------------------
    # PROMPT
    # -----------------------------------

    prompt = f"""
You are an expert Manufacturing Quality Engineer AI Assistant.

Analyze the manufacturing incident carefully.

CURRENT INCIDENT:
{incident_query}

SIMILAR PAST INCIDENTS:
{context}

Provide:

1. Probable Root Causes
2. Risk Severity
3. Corrective Actions
4. Preventive Measures
5. Executive Summary

Keep response:
- concise
- professional
- practical
- manufacturing focused
"""

    # -----------------------------------
    # STREAMING RESPONSE
    # -----------------------------------

    with st.chat_message("assistant"):

        placeholder = st.empty()

        full_response = ""

        for chunk in llm.stream(prompt):

            if chunk.content:

                full_response += chunk.content

                placeholder.markdown(
                    full_response + "▌"
                )

        placeholder.markdown(full_response)

    # -----------------------------------
    # SHOW RETRIEVED INCIDENTS
    # -----------------------------------

    with st.expander("Retrieved Similar Incidents"):

        for i, doc in enumerate(docs, start=1):

            st.markdown(f"### Incident {i}")

            st.write(doc.page_content)

