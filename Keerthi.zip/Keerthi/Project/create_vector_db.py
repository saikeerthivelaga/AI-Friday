# import pandas as pd
# from langchain_core.documents import Document
# from langchain_community.vectorstores import FAISS
# from langchain_community.embeddings import HuggingFaceEmbeddings

# # Load CSV
# df = pd.read_csv("incidents.csv")

# documents = []

# # Convert rows into documents
# for _, row in df.iterrows():

#     content = f"""
#     Timestamp: {row['timestamp']}
#     Line: {row['line']}
#     Plant: {row['plant']}
#     Product: {row['product']}
#     Incident: {row['incident']}
#     Root Cause: {row['root_cause']}
#     Action: {row['action']}
#     """

#     documents.append(
#         Document(page_content=content)
#     )

# # Embedding model
# embeddings = HuggingFaceEmbeddings(
#     model_name="sentence-transformers/all-MiniLM-L6-v2"
# )

# # Create FAISS vector DB
# vectorstore = FAISS.from_documents(
#     documents,
#     embeddings
# )

# # Save vector DB
# vectorstore.save_local("faiss_index")

# print("✅ FAISS Vector Database Created")
import pandas as pd

from langchain_core.documents import Document
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import FakeEmbeddings

# Load CSV
df = pd.read_csv("incidents.csv")

documents = []

for _, row in df.iterrows():

    content = f"""
    Timestamp: {row['timestamp']}
    Line: {row['line']}
    Plant: {row['plant']}
    Product: {row['product']}
    Incident: {row['incident']}
    Root Cause: {row['root_cause']}
    Action: {row['action']}
    """

    documents.append(
        Document(page_content=content)
    )

# Simple embeddings
embeddings = FakeEmbeddings(size=384)

# Create vector DB
vectorstore = FAISS.from_documents(
    documents,
    embeddings
)

# Save DB
vectorstore.save_local("faiss_index")

print("✅ Vector DB Created Successfully")

