from langchain_openai import ChatOpenAI
import httpx

client = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key="sk-49TG187D4OST1pMY2Q_-JQ",
    http_client=client
)



while True:
    user_query = input("You: ")

    if user_query.lower() in ["exit", "quit"]:
        print("Goodbye!")
        break

    else:
        # response = llm.invoke(user_query)
        # print(response.content)
        for chunk in llm.stream(user_query):
            if chunk.content:
                print(chunk.content, end="", flush=True)
                time.sleep(0.02)
        print("\n")