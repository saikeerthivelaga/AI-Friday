from langchain_openai import ChatOpenAI  
import os  
import httpx 
import tiktoken
tiktoken_cache_dir = "Y:\Hackathon\Ahmedabad\Garima Park\05 06 2026\Team 7\Keerthi\9b5ad71b2ce5302211f9c61530b329a4922fc6a4"  ##Here paste the Directory path of your file.
os.environ["TIKTOKEN_CACHE_DIR"] = tiktoken_cache_dir
print("Program started")

client = httpx.Client(verify=False) 
llm = ChatOpenAI( 
base_url="https://genailab.tcs.in" ,
model = "azure_ai/genailab-maas-DeepSeek-V3-0324", 
api_key="sk-49TG187D4OST1pMY2Q_-JQ",
http_client = client 
) 
llm.invoke("Hi") 