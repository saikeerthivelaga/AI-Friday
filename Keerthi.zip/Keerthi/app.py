# import streamlit as st
# from langchain_openai import ChatOpenAI
# import httpx

# # HTTP client
# client = httpx.Client(verify=False)

# # LLM setup
# llm = ChatOpenAI(
#     base_url="https://genailab.tcs.in",
#     model="azure_ai/genailab-maas-DeepSeek-V3-0324",
#     api_key="sk-49TG187D4OST1pMY2Q_-JQ",
#     http_client=client
# )

# # Streamlit UI
# st.title("🤖 AI Chatbot")

# # Chat history
# if "messages" not in st.session_state:
#     st.session_state.messages = []

# # Display old messages
# for message in st.session_state.messages:
#     with st.chat_message(message["role"]):
#         st.markdown(message["content"])

# # User input
# user_query = st.chat_input("Type your message...")

# if user_query:

#     # Show user message
#     with st.chat_message("user"):
#         st.markdown(user_query)

#     st.session_state.messages.append(
#         {"role": "user", "content": user_query}
#     )

#     # Get AI response
#     response = llm.invoke(user_query)

#     bot_reply = response.content

#     # Show assistant response
#     with st.chat_message("assistant"):
#         st.markdown(bot_reply)

#     st.session_state.messages.append(
#         {"role": "assistant", "content": bot_reply}
#     )
# 
# import streamlit as st
# from langchain_openai import ChatOpenAI
# import httpx
# import time

# # HTTP client
# client = httpx.Client(verify=False)

# # LLM setup
# llm = ChatOpenAI(
#     base_url="https://genailab.tcs.in",
#     model="azure_ai/genailab-maas-DeepSeek-V3-0324",
#     api_key="sk-49TG187D4OST1pMY2Q_-JQ",
#     http_client=client,
#     streaming=True
# )

# # Streamlit page
# st.title("🤖 AI Chatbot")

# # Store chat history
# if "messages" not in st.session_state:
#     st.session_state.messages = []

# # Display previous chat messages
# for message in st.session_state.messages:
#     with st.chat_message(message["role"]):
#         st.markdown(message["content"])

# # User input
# user_query = st.chat_input("Type your message...")

# if user_query:

#     # Show user message
#     with st.chat_message("user"):
#         st.markdown(user_query)

#     # Save user message
#     st.session_state.messages.append({
#         "role": "user",
#         "content": user_query
#     })

#     # Assistant response area
#     with st.chat_message("assistant"):

#         # Empty placeholder
#         message_placeholder = st.empty()

#         full_response = ""

#         # Stream response
#         for chunk in llm.stream(user_query):

#             if chunk.content:

#                 full_response += chunk.content

#                 # Update UI continuously
#                 message_placeholder.markdown(full_response + "▌")

#                 time.sleep(0.01)

#         # Final response without cursor
#         message_placeholder.markdown(full_response)

#     # Save assistant response
#     st.session_state.messages.append({
#         "role": "assistant",
#         "content": full_response
#     })

import os
import time
import httpx
import streamlit as st
from langchain_openai import ChatOpenAI

# --- Config ---
# Put your key in env: export OPENAI_API_KEY="sk-***"
API_KEY = "sk-49TG187D4OST1pMY2Q_-JQ"  # or st.secrets["OPENAI_API_KEY"]
BASE_URL = "https://genailab.tcs.in"
MODEL_ID = "azure_ai/genailab-maas-DeepSeek-V3-0324"

# --- HTTP client (disable TLS verification only if you must) ---
client = httpx.Client(verify=False)

# --- LLM setup ---
llm = ChatOpenAI(
    base_url=BASE_URL,
    model=MODEL_ID,
    api_key=API_KEY,
    http_client=client,
    streaming=True,
)

# --- Streamlit UI ---
st.set_page_config(page_title="AI Chatbot", page_icon="🤖")
st.title("🤖 AI Chatbot")

# Sidebar controls
with st.sidebar:
    st.subheader("Session")
    if st.button("Reset chat"):
        st.session_state.messages = []
        st.experimental_rerun()

# Initialize chat history
if "messages" not in st.session_state:
    st.session_state.messages = []

# Render previous messages
for m in st.session_state.messages:
    with st.chat_message(m["role"]):
        st.markdown(m["content"])

# Get user input
user_query = st.chat_input("Type your message...")

def is_exit_cmd(text: str) -> bool:
    t = text.strip().lower()
    return t in {"exit", "quit", "bye", "goodbye"}

if user_query:
    # Handle local exit without calling the LLM
    if is_exit_cmd(user_query):
        with st.chat_message("assistant"):
            st.markdown("Goodbye! 👋")
        st.session_state.messages.append(
            {"role": "assistant", "content": "Goodbye! 👋"}
        )
        # Optionally auto-clear after a moment:
        # time.sleep(0.8); st.session_state.messages = []; st.experimental_rerun()
    else:
        # Show user message
        with st.chat_message("user"):
            st.markdown(user_query)
        st.session_state.messages.append({"role": "user", "content": user_query})

        # Stream assistant response
        with st.chat_message("assistant"):
            placeholder = st.empty()
            full = []
            for chunk in llm.stream(user_query):
                text = chunk.content or ""
                if not text:
                    continue
                full.append(text)
                placeholder.markdown("".join(full) + "▌")
                # Keep the UI snappy but not jittery
                # time.sleep(0.005)
            final_text = "".join(full)
            placeholder.markdown(final_text)

        st.session_state.messages.append(
            {"role": "assistant", "content": final_text}
        )
